CG - Assignment 3
_______________________________________________________
Team Member:
Suchakree	Sawangwong		5888170 Sec.1
Amonnat		Tengputtipong		5888202	Sec.1
_______________________________________________________
Detail:
We have 2 main object.
- Broom	(Plane 1)
- Cat	(Plane 2)
  - Body(Body)
  - Head(Subpart)
  - Star(Subsubpart)
_______________________________________________________
Controler:
	s   = moves the plane forward
	f   = moves the plane backward
	q,e = rolls the plane
	a   = yaws the plane
	x   = pitches the plane
	
	r   = rotates Body
	t   = rotates Head
	y   = rotates star

	v   = select camera to view
	b   = select camera to control
_______________________________________________________


